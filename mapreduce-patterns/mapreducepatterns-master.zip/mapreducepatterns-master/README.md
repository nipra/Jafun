mapreducepatterns
=================

Repository for MapReduce Design Patterns (O'Reilly 2012) example source code