oozie job -oozie http://sachidn001.hq.navteq.com:11000/oozie/  -kill $1
