package com.practicalHadoop.geotile;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Places
{
    private static final Logger logger = LoggerFactory.getLogger(Places.class);
    
    public static void main(String[] args)
    {
            logger.info("geotile Places OK");
    }

}
