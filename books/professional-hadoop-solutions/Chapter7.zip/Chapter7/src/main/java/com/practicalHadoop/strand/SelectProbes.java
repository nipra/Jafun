package com.practicalHadoop.strand;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SelectProbes
{
    private static final Logger logger = LoggerFactory.getLogger(SelectProbes.class);
    
    public static void main(String[] args)
    {
        logger.info("SelectProbes OK");
    }
}
//TRACE < DEBUG < INFO <  WARN < ERROR   +   ALL & OFF