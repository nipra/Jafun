package com.practicalHadoop.places;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.practicalHadoop.strand.Attendance;

public class Select
{
    private static final Logger logger = LoggerFactory.getLogger(Attendance.class);
    
    public static void main(String[] args)
    {
        logger.info("places Select OK");
    }
}
