package com.practicalHadoop.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DetermineError
{
    private static final Logger logger = LoggerFactory.getLogger(DetermineError.class);
    
    public static void main(String[] args)
    {
        logger.info("DetermineError OK");
    }
}
