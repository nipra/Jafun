package com.practicalHadoop.strand;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BuildStrands
{
    private static final Logger logger = LoggerFactory.getLogger(BuildStrands.class);
    
    public static void main(String[] args)
    {
        logger.info("BuildStrands OK");
    }
}
