package com.practicalHadoop.s3client;

public interface FileNameConverter {
	
	public String convertName(String name);

}
