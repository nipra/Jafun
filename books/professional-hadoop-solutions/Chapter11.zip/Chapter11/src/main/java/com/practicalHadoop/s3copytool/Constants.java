package com.practicalHadoop.s3copytool;

public class Constants {
	public static final String HDFS_PATH_PROPERTY = "HDFS_PATH";
	public static final String S3_PATH_PROPERTY = "S3_PATH";
	public static final String LOG_LEVEL_PROPERTY = "LOG_LEVEL";
	public static final String THREADS_PROPERTY = "THREADS";
	public static final String QUEUE_PROPERTY = "QUEUE";
	public static final String MAPCOUNT_PROPERTY = "MAPCOUNT";
}
