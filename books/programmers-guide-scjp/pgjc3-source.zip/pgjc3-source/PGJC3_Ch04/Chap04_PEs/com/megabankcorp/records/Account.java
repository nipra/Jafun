//Filename: Account.java
package com.megabankcorp.records;

public class Account { }