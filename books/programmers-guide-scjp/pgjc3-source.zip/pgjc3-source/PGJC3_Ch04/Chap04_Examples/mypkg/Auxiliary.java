package mypkg;

public class Auxiliary {
  public static int binarySearch(int[] a, int key) { // Same in java.util.Arrays.
    // Implementation is omitted.
    return -1;
  }
}