package mypkg;

public enum State { BUSY, IDLE, BLOCKED }