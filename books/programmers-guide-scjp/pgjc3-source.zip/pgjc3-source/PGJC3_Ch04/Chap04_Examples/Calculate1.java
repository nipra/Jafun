class Calculate1 {
  public static void main(String[] args) {
    double x = 10.0, y = 20.5;
    double squareroot = Math.sqrt(x);
    double hypotenue = Math.hypot(x, y);
    double area = Math.PI * y * y;
  }
}