import static java.lang.Math.*;
// All static members from Math are imported.
class Calculate2 {
  public static void main(String[] args) {
    double x = 10.0, y = 20.5;
    double squareroot = sqrt(x);
    double hypotenue = hypot(x, y);
    double area = PI * y * y;
  }
}