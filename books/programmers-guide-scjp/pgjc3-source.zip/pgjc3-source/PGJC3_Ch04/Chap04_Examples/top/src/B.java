package pkg;

public class B { }