package pkg;

public class A { B b; }