//File: Circus.java
import wizard.pandorasBox.*;             // Import of classes.

public class Circus {
  Clown performerOne;                    // OK. Simple class name
  wizard.pandorasBox.Clown performerTwo; // OK. Fully qualified class name

//LovePotion moreTLC;                    // Error. Not accessible
//Magic magician;                        // Error. Not accessible
}