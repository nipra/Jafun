
public interface XListener extends java.util.EventListener {
  public void methodAInXListener(XEvent e);
}