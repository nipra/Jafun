
public class SourceObject {
  public synchronized void addXListener(XListener listener) { /* ... */ }
  public synchronized void removeXListener(XListener listener) { /* ... */ }
}