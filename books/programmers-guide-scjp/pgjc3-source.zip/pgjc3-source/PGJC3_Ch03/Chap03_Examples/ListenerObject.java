
public class ListenerObject implements XListener {
  public void methodAInXListener(XEvent ev) { /* ... */ }
}