
public class XEvent extends java.util.EventObject {
  public XEvent(Object source) {
    super(source);
  }
}