// Filename: MachineState.java
public enum MachineState { BUSY, IDLE, BLOCKED }