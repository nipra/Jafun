
public interface Tool {
  public void setContext(EditContext newContext);
  public boolean isActive();
}