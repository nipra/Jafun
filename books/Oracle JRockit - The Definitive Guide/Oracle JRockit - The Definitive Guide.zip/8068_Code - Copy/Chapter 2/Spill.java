public class Spill {
    static int aField, bField, cField, dField;
    static int eField, fField, gField, hField;       
    static int answer;
    
    public static void main(String args[]) {
	int a = aField;
	int b = bField;
	int c = cField;
	int d = dField;
	int e = eField;
	int f = fField;
	int g = gField;
	int h = hField;

	answer = a*b*c*d*e*f*g*h;        
    }      	       	      
}
