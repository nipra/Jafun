public class Code
extends java.io.PrintStream
{
public static void
main(String[] args)
{
0: getstatic #12
3: aload_0
4: iconst_0
5: aaload
6: invokevirtual #15
9: return
}
}
