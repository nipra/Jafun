public class Even {
    public boolean even(int number) {
	return (number & 1) == 0;
    }
}
