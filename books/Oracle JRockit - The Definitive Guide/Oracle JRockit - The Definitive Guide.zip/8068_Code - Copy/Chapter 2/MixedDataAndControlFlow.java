public class MixedDataAndControlFlow {
    public static int test(boolean x, int a, int b) {
	return x ? a : b;
    }
}