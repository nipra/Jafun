JMXMAPI example that works like a remote version of JRCMD.

1. First start the DoNothing class with -Xmanagement:port=4711,ssl=false,authenticate=false.
2. Then launch RemoteJRCMD with the parameters of your choice. See the class comment for 
   more information.