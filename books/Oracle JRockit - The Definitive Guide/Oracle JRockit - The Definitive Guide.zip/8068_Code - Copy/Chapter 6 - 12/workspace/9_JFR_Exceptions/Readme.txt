This example shows how to record information about exceptions.

1. Run ExceptionTrower.
2. Record a flight recording with the Profiling with Exceptions template.
3. How many exceptions were thrown in the recording?
4. From where?







































1. If using the incorrect recording template, no exception events will be recorded.
2. It is all in the Code | Exceptions tab.