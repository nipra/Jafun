public class ExceptionThrowerException extends Exception {
	private static final long serialVersionUID = 8497545293657938990L;

	public ExceptionThrowerException(String message) {
		super(message);
	}
}
