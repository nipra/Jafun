Some JMAPI examples. Each class is a stand alone example meant to be run
as an application. Text will usually be output in the Console view.