
public class Address {
	public String city, street;
	public int number, zip;
}
