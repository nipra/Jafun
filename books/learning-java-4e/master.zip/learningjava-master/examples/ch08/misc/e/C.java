import java.util.*;

/*
public class C<E extends C<E>> 
{
	void take( E element ) { }
}
*/

//class D extends C<D> { }
//class D<E> extends C<D<E>> { }

class Main {
	public static void main( String [] args ) {
		enum Foo { A, B }

	}
}
