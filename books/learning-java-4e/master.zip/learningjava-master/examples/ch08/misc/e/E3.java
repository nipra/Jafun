import java.util.*;
import static java.util.concurrent.TimeUnit.*;

public class E3 
{

	public static void main( String [] args ) throws Exception
	{
		SECONDS.sleep(3);
	}

}
