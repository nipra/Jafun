import java.util.*;

public class RT 
{
	List<? extends Date> foo() { return new ArrayList<Date>(); }

}
