import java.util.*;

public class SC 
{

	public static void main( String [] args ) throws Exception
	{
		String s = String.class.newInstance();
	}

}
