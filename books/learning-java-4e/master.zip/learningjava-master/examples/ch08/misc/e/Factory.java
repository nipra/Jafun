import java.util.*;

public class Factory 
{
	public static <T> T make()
	{
		Class<T> ct = T.class;
	}
}

class Main {

	public static void main( String [] args ) 
	{
	}
}
