import java.util.*;

public class Q2 
{
	public static void main( String [] args )
	{
		new Q1<Date>();
	}

}
