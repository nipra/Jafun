import java.util.*;

public class AR 
{
	public static void main( String [] args )
	{
		List<Date> [] la = new ArrayList[5]; // unchecked warning





		List<Date> ld = la[0];
		
	}

}
