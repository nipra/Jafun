
enum Cat { Persian, Himalayan, ShortHair };
