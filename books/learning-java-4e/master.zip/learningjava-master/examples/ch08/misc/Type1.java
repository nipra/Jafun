import java.util.*;

public class Type1<T>
{
	static T t;

	public static void main( String [] args )
	{
	}

}
