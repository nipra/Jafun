package bbejeck.guava.common.model;

/**
 * User: Bill Bejeck
 * Date: 4/3/13
 * Time: 9:47 PM
 */
public enum Climate {
    SUB_TROPICAL, TEMPERATE, DESERT, HUMID
}
