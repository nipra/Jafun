package bbejeck.guava.common.model;

/**
 * User: Bill Bejeck
 * Date: 4/3/13
 * Time: 11:34 PM
 */
public enum Region {
    NORTH,NORTHEAST,SOUTH,MIDWEST,PACIFIC_NORTHWEST,SOUTHWEST,NO_REGION
}
