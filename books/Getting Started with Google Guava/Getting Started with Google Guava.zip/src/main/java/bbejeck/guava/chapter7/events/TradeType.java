package bbejeck.guava.chapter7.events;

/**
 * User: Bill Bejeck
 * Date: 4/26/13
 * Time: 10:26 AM
 */
public enum TradeType {

    BUY,SELL
}
