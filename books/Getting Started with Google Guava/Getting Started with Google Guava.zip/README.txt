This is the source code for the Getting Started with Google Guava book.

You can use either Maven or Gradle to build this project:

Maven run - mvn clean test or clean package

Gradle run - clean test or clean build

If you don't have Gradle or Maven installed, it is strongly suggested to do so.