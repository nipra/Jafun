package managedBean;

import javax.faces.bean.ManagedBean;

@ManagedBean(name = "dossierClientBean")
public class DossierClientBean {

    public DossierClientBean() {
        super();
    }

}
